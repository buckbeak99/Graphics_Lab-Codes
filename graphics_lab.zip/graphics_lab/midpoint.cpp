#include<GL/glut.h>
#include<bits/stdc++.h>
using namespace std;

GLint x1, y1, r, sizes=1000;

void Init(void)
{
    glClearColor(0.0,1.0,1.0,0.0);
    glColor3f(1.0f,0.0f,0.0f);
    glPointSize(2.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-sizes/2,sizes/2,-sizes/2,sizes/2,-1,1);
}

void giveInput()
{
    printf("Enter X coordinate: ");
    scanf("%i",&x1);
    printf("Enter Y coordinate: ");
    scanf("%i",&y1);
    printf("Enter Radius: ");
    scanf("%i",&r);
}

void pixel(GLint x_coordinate, GLint y_coordinate)
{
    glBegin(GL_POINTS);
    glVertex2i(x_coordinate,y_coordinate);
    glEnd();
    glFlush();
}

void draw_axis()
{
    GLint i=(-sizes)/2;
    for(; i<(sizes/2); i++)
    {
        pixel(i,0);
        pixel(0,i);
    }
}

void draw(GLint xk,GLint yk, GLint xc,GLint yc)
{
    pixel(xc+xk,yc+yk);
    pixel(xc+yk,yc+xk);
    pixel(xc-yk,yc+xk);
    pixel(xc-xk,yc+yk);
    pixel(xc-xk,yc-yk);
    pixel(xc-yk,yc-xk);
    pixel(xc+yk,yc-xk);
    pixel(xc+xk,yc-yk);
}

void midPoint(GLint xc,GLint yc,GLint r)
{
    GLint pk,xk,yk;
    pk=1-r;
    xk=0;
    yk=r;
    draw(xk,yk,xc,yc);
    while(xk<=yk)
    {
        if(pk<0)
        {
            xk=xk+1;
            pk=pk+(2*xk)+1;
        }
        else
        {
            xk=xk+1;
            yk=yk-1;
            pk=pk+(2*xk)+1-(2*yk);
        }
        draw(xk,yk,xc,yc);
    }

}

void DisplayCircle(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    //draw_axis();
    midPoint(xc,yc,r);
}

int main(int argc,char *argv[])
{
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(600,600);
    glutInitWindowPosition(50,50);
    glutCreateWindow("Mid Point");
    giveInput();
    glutDisplayFunc(DisplayCircle);
    Init();
    glutMainLoop();
    return 0;
}
